import React from 'react';
import ShopPage from './components/ShopPage';

function App() {
  return (
    <div className="h-screen w-full">
      <ShopPage />
    </div>
  );
}

export default App;